class Laser {
  //member vari
  int x, y, w, h, speed;

  Laser(int x, int y, int speed) {
    this.x=x;
    this.y=y;
    w=8;
    h=12;
    speed=5;
    
  }
  
  void display() {
    fill(44,222,22);
    rectMode(CENTER);
    rect(x,y,w,h);
  }
  
  
 void move() {
 y=y-speed;
 }
 
 boolean isOffScreen() {
    if (y<-10) {
      return true;
    } else {
      return false;
    }
  }
}
