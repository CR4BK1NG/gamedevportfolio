class PowerUp {
  //member variables
  int x, y, size, speed;
  char type;
  boolean isHit;
  PImage pu1;

  //constructor
  PowerUp (int x, int y) {
    this.x=x;
    this.y=y;
    size=int(random(20, 100));
    speed=int(random(1, 4));
    if (random(3)>2.0) {
      type='h';
      pu1=loadImage("");
    } else if (random(2)>1.0) {
      type = 't';
      pu1=loadImage("");
    } else {
      type ='s';
      pu1=loadImage("");
    }
    isHit=false;
    
  }

  //member methods
  void display() {
    fill(55,200,44);
    //image(pu1,x,y);
    ellipse(x, y, size, size);
    textAlign(CENTER, CENTER);
    fill(255);
    text(type, x, y);
    
  }

  void move() {
    y=y+speed;
  }
  
  boolean isOffScreen() {
    if (y>height+50) {
      return true;
    } else {
      return false;
    }
  }
  
  
  
  boolean isHit(starboy s) {
  float d;
  }
  
}
