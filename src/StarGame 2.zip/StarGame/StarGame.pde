// Gideon Gordon | 16 Sept 2026 | Starboy
// Storage for code i will import later
//Gif myAnimation;

//void setup() {
//    size(400,400);
//    myAnimation = new Gif(this, "lavalamp.gif");
//    myAnimation.play();
//}

//void draw() {
//    image(myAnimation, 10, 10);
//}
//Will add gif animation later due to confusion

import gifAnimation.*;
import processing.sound.*;
SoundFile laser01;
Gif myAnimation;
ArrayList<Rock> rocks = new ArrayList<Rock>();
ArrayList<Laser> lasers = new ArrayList<Laser>();
ArrayList<PowerUp> powUps = new ArrayList<PowerUp>();
Starboy starboy01;
Boss b1;
Timer rDist, puDist, bossFreq;
int score, rockCount, rocksOffScreen, laserSpeed, level;
boolean play;

void setup() {
  frameRate(30);
  size(800, 1000);
  size(400, 400);
  laser01 = new SoundFile(this, "l1.mp3");
  myAnimation = new Gif(this, "starboy.gif");
  myAnimation.play();



//rocks.add(new Rock(int(random(width)), -60));
//powUps.add(new PowerUp(int(random(width)), -60));
starboy01= new Starboy(width/2, height/2);
rDist=new Timer(1000);
puDist= new Timer(3000);
puDist.start();
rDist.start();
bossFreq= new Timer(30000);
bossFreq.start();
score=0;
rockCount=0;
laserSpeed= 5;

}
void draw() {

  noCursor();
  background(20);
  image(myAnimation, 10, 10);


  //add rocks
  if (rDist.isFinished()==true) {
    // spawn new rock
    rocks.add(new Rock(int(random(width)), -60));
    // reset timer
    rDist.start();
  }


  if (puDist.isFinished()==true) {
    powUps.add(new PowerUp(int(random(width)), -60));
    puDist.start();
  }
  //rocks.add(new Rock(int(random(width)),-60));
  starboy01.move(mouseX, mouseY);
  starboy01.display();

  for (int i = 0; i < lasers.size(); i++) {
    println("Lasers:"+ lasers.size());
    Laser l = lasers.get(i);
    for (int j = 0; j < rocks.size(); j++) {
      Rock r = rocks.get(j);
      if (r.isHit(l)) {
      }
    }
    l.display();
    l.move();
    if (l.isOffScreen()==true) {
      lasers.remove(l);
    }
    println(lasers.size());
  }
  for (Rock r : rocks) {
    println(rocks.size());
  }
  for (int i =0; i < rocks.size(); i++) {
    println(rocks.size());
    Rock r = rocks.get(i);
    r.display();
    r.move();
    if (starboy01.isHit(r)) {
      rocks.remove(r);
      score += 100;
    }
    if (r.isOffScreen()==true) {
      rocks.remove(r);
    }
    for (int i = 0; i < powUps.size(); i++) {
      PowerUp pu = powUps.get(i);
      pu.display();
      pu.move();
      if (pu.isHit(starboy01)) {
        if (pu.type == 'h') {
          starboy01.health += 100;
          powUps.remove(pu);
        } else if (pu.type == 's') {
        }
        laserSpeed = laserSpeed + 1;
        powUps.remove(pu);
      } else if (pu.type == 't') {
        laserSpeed = turretCount += 1;
        powUps.remove(pu);
      }
    }
    if (pu.isOffScreen() ==true) {
      powUps.remove(pu);
    }
    //println("Power Ups: " + powUps.size());
  }
}
void mousePress() {
  if (starboy01.turretCount == 1) {
    lasers.add(new Laser(starboy01.x, starboy01.y));
  } else if (ship01.turretCount ==2) {
    lasers.add(new Laser(starboy01.x-20, starboy01.y));
    lasers.add(new Laser(starboy01.x+20, starboy01.y));
  } else if (ship01.turretCount ==3) {
    lasers.add(new Laser(starboy01.x, starboy01.y));
    lasers.add(new Laser(starboy01.x, starboy01.y));
    lasers.add(new Laser(starboy01.x, starboy01.y));
  }
}



//addinfopanel
void infoPanel() {
  fill(127, 127);
  rectMode(CORNER);
  rect(0, 0, width, 40);
  fill(255);
  textSize(35);
  textAlign(CORNER, CORNER);
  text("Score:"+score, 20, 35);
  text("Rock Count:"+starboyheatlth, 180, 35);
  text("Score:"+score, 20, 35);
}
}
