class Rock {
  //member variables
  int x, y, w, h, health, speed;
  boolean isHit;
  PImage r1;

  //constructor
  Rock (int x, int y) {
    this.x=x;
    this.y=y;
    w=int(random(20, 100));
    h=int(random(20, 100));
    speed=int(random(1, 10));
    health=100;
    isHit=false;
    //r1=loadImage("Rock.png");
  }

  //member methods
  void display() {
    imageMode(CENTER);
    image(r1, x, y);
    //fill(127);
    //ellipse(x, y, w, h);
    //textAlign(CENTER, CENTER);
    //text(health, x, y);
  }

  void move() {
    y=y+speed;
  }

  boolean isOffScreen() {
    if (y>height+50) {
      return true;
    } else {
      return false;
    }
  }
  boolean isHit(Laser l) {
    float d = dist(x, y, l.x, l.y);
    if (d<10) {
      return true;
    } else {
      return false;
    }
  }
}
